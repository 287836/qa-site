import sys
path = '/home/你的用户名/qa-site'
if path not in sys.path:
    sys.path.append(path)

from server import app as application
