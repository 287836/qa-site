@echo off
echo Starting QA Site...
python "%~dp0server.py"
pause
