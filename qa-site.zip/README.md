# 部署到 PythonAnywhere

## 第一步：注册

1. 打开 https://www.pythonanywhere.com
2. 点 **Pricing & sign up** -> **Create a Beginner account**（免费）
3. 注册完登录

## 第二步：上传文件

1. 登录后，点顶部 **Files**
2. 在 `/home/你的用户名/` 下，点 **Upload a file**
3. 上传 `qa-site.zip`（或者手动上传 server.py 和 templates 文件夹）
4. 回到 Files 页面，打开 **Bash Console**（点顶部 **Consoles** -> **Bash**）
5. 在控制台运行：

```bash
cd ~
mkdir qa-site
cd qa-site
# 如果传了 zip：
unzip ~/qa-site.zip -d .
# 否则手动创建 templates 文件夹：
mkdir templates
```

## 第三步：安装依赖

```bash
pip install flask --user
```

## 第四步：配置 Web 应用

1. 点顶部 **Web**
2. 点 **Add a new web app**
3. 选 **Manual configuration** -> **Python 3.10**（或最新版本）
4. 等它创建好

## 第五步：编辑 WSGI 文件

1. 在 Web 页面，找到 **Code** 部分
2. 点 **WSGI configuration file** 的链接
3. **全选删除所有内容**，粘贴下面的代码：

```python
import sys
path = '/home/你的用户名/qa-site'
if path not in sys.path:
    sys.path.append(path)

from server import app as application
```

把 `你的用户名` 换成你在 PythonAnywhere 的用户名。点 **Save**。

## 第六步：设置静态文件

在 Web 页面的 **Static files** 部分：

- URL: `/static/`
- Directory: `/home/你的用户名/qa-site/static/`

（本项目没有静态文件，但留着也没问题）

## 第七步：启动

1. 回到 Web 页面顶部
2. 点绿色的 **Reload** 按钮
3. 等几秒钟

## 大功告成！

你的网站地址是：`https://你的用户名.pythonanywhere.com`

把它发给你朋友，他们就能上来提问了！

---

> 注意：免费版长时间没人访问会休眠。有人访问时会自动唤醒，稍等几秒就好。
> 数据存在 qa.db 文件里，只要不删除文件，数据就在。
